#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <algorithm>
using namespace std;
char space_seperator = ' ';
char colon_seperator = ':';
char line_seperator ='|';
string YES = "YES";
string NO = "NO";
string IF_NECESSARY = "IF_NECESSARY";
int number_of_printed_slots=0;

int find_string_length(string str);
vector <string> split_names (string str, char seperator);
vector <string> split_line_into_strings (string str, char line_seperator, char colon_seperator);
vector <string> recieve_names(int n);
string who_is_voting(vector <string> splited_line,vector <string> splited_names);
string select_first_char(string a);
int convert_char_to_int(string a);
int is_yes(string str);
int is_no(string str);
int is_if_necessary(string str);
vector <vector<vector<string> > >  check_voters (vector <string> splited_names,
                 vector<vector<vector<string> > > votes ,int m, int num_of_row);
vector <vector<vector<string> > > find_who_didnot_vote (vector <string> splited_names,
               vector<vector<vector<string> > > votes , int n , int num_of_row);
vector<int> find_slot_index_with_minimun_NO (vector<vector<vector<string> > > votes,
                                 vector<int> number_of_NO, int n , int top3_slots);
vector<int> find_number_of_NO (vector<vector<vector<string> > > votes , int n);
void print_output(vector<vector<vector<string> > > votes,vector<int> index_of_minimom_NOs, int num_of_NOs);
void print_output2(vector<vector<vector<string> > > votes,vector<int> index_of_minimom_NOs, int num);
void best_slots_less2(vector<vector<vector<string> > > votes,vector<int> index_of_minimom_NOs);
void best_slots_equal2(vector<vector<vector<string> > > votes,vector<int> index_of_minimom_NOs);
void find_best_slot (vector<vector<vector<string> > > votes, vector<int> number_of_NO, int n,int top3_slots);
vector <vector<vector<string> > > detect_votes (vector<vector<vector<string> > > votes,
                                                string current_voter,vector <string> splited_line );


int main()
{
  int n;
  vector < vector <vector <string> > > votes ;
  vector <string> splited_names;
  vector <vector <string> > lines ;
  string str;
  string names;

  cin >> n ;
  cin.ignore();
  getline(cin,names);
  splited_names = split_names(names,space_seperator);
  while (getline(cin,str) )
  {
    vector <string> splited_line;
    splited_line = split_line_into_strings(str, line_seperator, colon_seperator);

    for (int i =0 ; i<n ; i++)
    {
      vector <vector <string> > in_votes (3);
      votes.push_back(in_votes);
    }
    string current_voter = who_is_voting(splited_line,splited_names);
    votes = detect_votes(votes, current_voter, splited_line);
  }
  for (int i = 0; i<n; i++ )
  {
    votes = find_who_didnot_vote(splited_names,votes,n,i);
  }
  for(int k =0 ; k<3 ; k++)
  {
    if (number_of_printed_slots == 0 )
      find_best_slot (votes , find_number_of_NO(votes, n),n,0);
    else if (number_of_printed_slots == 1)
      find_best_slot (votes , find_number_of_NO(votes, n),n,1);
    else if(number_of_printed_slots ==2)
      find_best_slot (votes , find_number_of_NO(votes, n),n,2);

    if(number_of_printed_slots >= 3)
      break;
  }
return 0;

}
vector <vector<vector<string> > > detect_votes (vector<vector<vector<string> > > votes,
                                                string current_voter,vector <string> splited_line )
{
  for (int i = 1; i < splited_line.size(); i++)
  {
    int vote;
    vote = convert_char_to_int(select_first_char(splited_line[i]));

    if (is_yes(splited_line[i]) == 1 )
    {
      votes [vote][0].push_back(current_voter);
    }
    if (is_no(splited_line[i]) == 1 )
    {
    votes [vote][1].push_back(current_voter);
    }
  }
  return votes;
}
void best_slots_less2(vector<vector<vector<string> > > votes,vector<int> index_of_minimom_NOs)
{
    if (votes[index_of_minimom_NOs[0]][2].size()<votes[index_of_minimom_NOs[1]][2].size())
    {   print_output2(votes,index_of_minimom_NOs,0);
        print_output2(votes,index_of_minimom_NOs,1);
    }
    else if (votes[index_of_minimom_NOs[0]][2].size() > votes[index_of_minimom_NOs[1]][2].size())
    {   print_output2(votes,index_of_minimom_NOs,1);
        print_output2(votes,index_of_minimom_NOs,0);
    }
    else if (votes[index_of_minimom_NOs[0]][2].size() == votes[index_of_minimom_NOs[1]][2].size())
    { if(index_of_minimom_NOs[0] > index_of_minimom_NOs[1])
      {   print_output2(votes,index_of_minimom_NOs,1);
          print_output2(votes,index_of_minimom_NOs,0);
      }
      else if (index_of_minimom_NOs[0] < index_of_minimom_NOs[1])
      {   print_output2(votes,index_of_minimom_NOs,0);
          print_output2(votes,index_of_minimom_NOs,1);
      }
    }
}

void best_slots_equal2(vector<vector<vector<string> > > votes,vector<int> index_of_minimom_NOs)
{
  if (votes[index_of_minimom_NOs[0]][2].size() < votes[index_of_minimom_NOs[1]][2].size())
        print_output2(votes,index_of_minimom_NOs,0);
    else if (votes[index_of_minimom_NOs[0]][2].size() > votes[index_of_minimom_NOs[1]][2].size())
        print_output2(votes,index_of_minimom_NOs,1);
    else if (votes[index_of_minimom_NOs[0]][2].size() == votes[index_of_minimom_NOs[1]][2].size())
    {
      if( index_of_minimom_NOs[0] > index_of_minimom_NOs[1])
        print_output2(votes,index_of_minimom_NOs,1);
      else if (index_of_minimom_NOs[0] < index_of_minimom_NOs[1])
        print_output2(votes,index_of_minimom_NOs,0);
    }
}

void find_best_slot
    (vector<vector<vector<string> > > votes, vector<int> number_of_NO, int n , int top3_slots)
{
  int current_slot;
  vector<int> index_of_minimom_NOs;
  index_of_minimom_NOs = find_slot_index_with_minimun_NO(votes,find_number_of_NO(votes,n), n, top3_slots);

  if (index_of_minimom_NOs.size() == 1)
  { print_output2(votes,index_of_minimom_NOs,0);  }
  else if (index_of_minimom_NOs.size() ==2)
  {   if(number_of_printed_slots <2)
    {
      best_slots_less2(votes,index_of_minimom_NOs);
    }
    else if(number_of_printed_slots == 2)
    {
      best_slots_equal2(votes,index_of_minimom_NOs);
    }
  }
}


void print_output2(vector<vector<vector<string> > > votes,vector<int> index_of_minimom_NOs, int num)
{
  cout << "Time slot " << index_of_minimom_NOs[num] << ":"<<endl;
  print_output(votes,index_of_minimom_NOs,num);
  number_of_printed_slots +=1;
}

void print_output(vector<vector<vector<string> > > votes,vector<int> index_of_minimom_NOs, int num_of_NOs)
{
  for(int j =0; j<3; j++)
  {
    if(j==0)
      cout <<"YES:";
    else if (j == 1)
      cout << "NO:";
    else
      cout <<"IF_NECESSARY:";
    for (int k = 0; k< votes[index_of_minimom_NOs[num_of_NOs]][j].size() ; k++)
      {
        cout << " "<< votes[index_of_minimom_NOs[num_of_NOs]][j][k];
      }  cout <<"\n";
  } cout << "###"<<endl;
}

vector<int> find_number_of_NO (vector<vector<vector<string> > > votes , int n)
{
    vector<int> number_of_NO;
    for (int i = 0; i<n; i++)
    {
      number_of_NO.push_back(votes[i][1].size());
    }
      sort(number_of_NO.begin(), number_of_NO.end());
      return number_of_NO ;
}

vector<int> find_slot_index_with_minimun_NO (vector<vector<vector<string> > > votes,
                                  vector<int> number_of_NO, int n , int top3_slots)
{
  vector<int> index_of_minimom_NOs;
  for (int i = 0; i<n; i++)
  {  if (votes[i][1].size() == number_of_NO[top3_slots])
      index_of_minimom_NOs.push_back(i);
  }
  return index_of_minimom_NOs;
}

vector <vector<vector<string> > > find_who_didnot_vote(vector <string> splited_names,
                vector<vector<vector<string> > > votes , int n , int num_of_row )
{
  for (int i = 0; i<n; i++)
  {
    if((votes[i][0].size() ==0) && (votes[i][1].size() ==0) && (votes[i][2].size() ==0))
    {
      for (int j=0; j<splited_names.size();j++)
          votes[i][2].push_back(splited_names[j]);
    }
    for (int m = 0 ; m< splited_names.size(); m++)
    {
      votes = check_voters(splited_names,votes,m,i);
    }
  }
  return votes;
}

vector <vector<vector<string> > >  check_voters(vector <string> splited_names,
                 vector<vector<vector<string> > > votes ,int m, int num_of_row)
{
  int existing_name_yes_flag =0;  int existing_name_no_flag =0;
  int existing_name_if_flag =0;
  for (int k =0; k<votes[num_of_row][0].size();k++)
  {
    if (votes[num_of_row][0][k] == splited_names[m])
      existing_name_yes_flag=1;
  }
  for (int k =0; k<votes[num_of_row][1].size();k++)
  {
    if (votes[num_of_row][1][k] == splited_names[m])
      existing_name_no_flag=1;
  }
  for (int k =0; k<votes[num_of_row][2].size();k++)
  {
    if (votes[num_of_row][2][k] == splited_names[m])
      existing_name_if_flag=1;
  }
    if (existing_name_if_flag==0 && existing_name_no_flag ==0 && existing_name_yes_flag ==0)
    {
      votes[num_of_row][2].push_back(splited_names[m]);
    }
    return votes;
}
 int is_yes(string str)
 {
   if (str.find(YES) != string::npos)
     return 1;
   else
     return 0;
 }

 int is_no(string str)
 {
   if (str.find(NO) != string::npos)
     return 1;
   else
     return 0;
 }
 int is_if_necessary(string str)
 {
   if (str.find(IF_NECESSARY) != string::npos)
     return 1;
   else
     return 0;
 }
string select_first_char(string a)
{
  int a_size = a.size();
  a.erase(1,a_size-1);
  return a;
}

 string who_is_voting(vector <string> splited_line,vector <string> splited_names )
 {
   int voting_flag=0;
   for (int i =0; i< splited_line.size(); i++)
   {
     for (int k =0; k< splited_names.size() ; k++)
     {
       if (splited_line[0] == splited_names[k])
          voting_flag =k;
     }
   }
   return splited_names[voting_flag];
 }
vector <string> recieve_names(int n)
{
  vector <string> names;
  string name;
  for (int i= 0; i < n ;i++)
  {
    cin >> name;
    names.push_back(name);
  }
  return names;
}

int convert_char_to_int(string a)
{
  stringstream str;
  str << a;
  int converted_to_int;
  str >> converted_to_int;
  return converted_to_int;
}
vector <string> split_line_into_strings (string str, char line_seperator, char colon_seperator) // : or | seperator
{
    int current_index =0;  int i =0;
    int starting_index =0; int ending_index =0;
    vector <string> strings_in_line;
    while (i <= find_string_length(str))
    {
      if (str[i] == line_seperator|| str[i] == colon_seperator || i == find_string_length(str))
      {
        ending_index = i;
        string sub_str = "";
        sub_str.append(str, starting_index, ending_index - starting_index);
        strings_in_line.push_back(sub_str);
        current_index +=1;
        starting_index = ending_index +1;
      }
      i++ ;
    }
    return strings_in_line;
 }

vector <string> split_names (string str, char seperator) // space seperator
{
    int current_index =0;
    int i =0;
    int starting_index =0;
    int ending_index =0;
    vector <string> strings_in_line;
    while (i <= find_string_length(str))
    {
      if (str[i] == space_seperator || i == find_string_length(str))
      {
        ending_index = i;
        string sub_str = "";
        sub_str.append(str, starting_index, ending_index - starting_index);
        strings_in_line.push_back(sub_str);
        current_index +=1;
        starting_index = ending_index +1;
      }
      i++ ;
    }
    return strings_in_line;
 }
int find_string_length(string str)
{
  int length = 0;
  for (int i =0; str[i] != '\0'; i++)
  {
    length ++;
  }
  return length ;
}
