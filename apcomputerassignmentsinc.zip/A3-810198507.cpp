#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>


using namespace std;
#define CAMMA_SEPERATOR ','
#define COLON_SEPERATOR ':'
#define OUTPUT_SEPERATOR "---"

const string openingTime = "openingTime";
const string closingTime = "closingTime";
const string LOCATION = "Location ";
const string VISIT_FROM = "Visit from ";
const string UNTIL = " until ";
const string PLACE_NAME = "name";
const string PLACE_RANK = "rank";
const int NUM_OF_COLUMNS = 4;
const int TRANSPORT_TIME = 30;
const int HOUR_DURATION = 60;

struct DATA
{
  string name;
  int opening_time_hour;
  int opening_time_minute;
  int closing_time_hour;
  int closing_time_minute;
  int rank;
};
struct VISIT
{
  string name_of_place;
  int visit_starting_time_hour;
  int visit_starting_time_minute;
  int visit_finishing_time_hour;
  int visit_finishing_time_minute;
};

vector<string> split (string str, char seperator);
int convert_char_to_int(string a);
void get_first_input_line(vector<string> &splited_columns, ifstream &input_file);
void get_other_input_lines(vector <string> &words,ifstream &input_file);
void read_from_file(vector <string> &words, vector<string> &splited_columns, char* file_name);
vector<int> read_time(string time);
void organize_input(vector<DATA> &input,vector <string> words,vector<string> splited_columns, int num_of_lines, int i);
void save_organized_inputs(vector<DATA> &input,vector <string> words,vector<string> splited_columns, int num_of_lines);
void what_time_is_it_now(vector<DATA> inputs,vector<int> indexes);
int time_difference(int hour1, int min1, int hour2, int min2);
void merge_sort(vector<int>& indexes, vector<DATA> inputs, int low, int mid, int high);
void merge_sort_times(vector<int>& v, vector<DATA> inputs, int low, int high);
void sort_ranks(vector<DATA> inputs, vector <int> &indexes);
bool enough_time_left_to_close(vector<DATA> inputs, vector <int> &indexes, int i);
void first_visit(vector<VISIT> &visits, vector<DATA> inputs, vector <int> &indexes, int &flag);
vector<int> calculate_transportation_time(vector<VISIT> &visits);
bool place_is_open_now(vector<int> arriving_time, vector<DATA> inputs, vector <int> &indexes , int i );
void find_next_visit(vector<VISIT> &visits, vector<DATA> inputs, vector <int> &indexes,int &visits_are_over);
void check_hour_zeros(int hour);
void check_minute_zeros(int minute);
void print_output(vector<VISIT> visits);
void recieve_places_data(vector<DATA> &inputs,int &num_of_lines, char* file_name);
void do_process_on_data(int num_of_lines, vector<DATA> &inputs,vector<VISIT> &visits, int &qabrestoon_flag);
void print_visits_plan(vector<VISIT> visits,int qabrestoon_flag);
bool place_will_be_open(vector<int> arriving_time, vector<DATA> inputs, vector <int> &indexes , int i);
bool check_closing_time_is_more_than_1h_1(vector<DATA> inputs, vector <int> &indexes , int i);
bool check_closing_time_is_more_than_1h_2(vector<int> arriving_time,vector<DATA> inputs, vector <int> &indexes , int i);


int main(int argc, char* argv[])
{
  vector<DATA> inputs;
  vector<VISIT> visits;
  int qabrestoon_flag = 0;
  int num_of_lines;
  char* file_name = argv[1];

  recieve_places_data(inputs,num_of_lines,file_name);
  do_process_on_data(num_of_lines,inputs,visits,qabrestoon_flag);
  print_visits_plan(visits,qabrestoon_flag);

  return 0;
}


void check_hour_zeros(int hour)
{
  if (hour < 10)
  {
    cout<<0<<hour<<COLON_SEPERATOR;
  }
  else
    cout<<hour<<COLON_SEPERATOR;
}

void check_minute_zeros(int minute)
{
  if (minute < 10)
  {
    cout<<0<<minute;
  }
  else
    cout<<minute;
}

void print_output(vector<VISIT> visits)
{
    for (int i =0; i< visits.size(); i++)
    {
      cout << LOCATION<< visits[i].name_of_place <<endl;
      cout <<VISIT_FROM;
      check_hour_zeros(visits[i].visit_starting_time_hour);
      check_minute_zeros(visits[i].visit_starting_time_minute);
      cout<< UNTIL;
      check_hour_zeros(visits[i].visit_finishing_time_hour);
      check_minute_zeros(visits[i].visit_finishing_time_minute);
      cout << endl;
      cout << OUTPUT_SEPERATOR<<endl;
    }
}

void recieve_places_data(vector<DATA> &inputs,int &num_of_lines, char *file_name)
{
  vector <string> words;
  vector<string> splited_columns;
  read_from_file(words,splited_columns,file_name);
  num_of_lines = ((words.size())/4);
  save_organized_inputs(inputs,words,splited_columns, num_of_lines);
}

void do_process_on_data(int num_of_lines, vector<DATA> &inputs,vector<VISIT> &visits, int &qabrestoon_flag)
{
  vector <int> input_indexes;
  for (int i = 0; i< num_of_lines; i++)
    input_indexes.push_back(i);

  merge_sort_times(input_indexes,inputs,0,num_of_lines-1);
  sort_ranks(inputs,input_indexes);
  what_time_is_it_now(inputs,input_indexes);
  first_visit(visits, inputs,input_indexes,qabrestoon_flag);
    if (qabrestoon_flag == 0)
    {
      while(true)
      {
        int visits_are_over = 1;
        find_next_visit(visits,inputs,input_indexes,visits_are_over);
        if (visits_are_over)
          break;
      }

    }
}

void print_visits_plan(vector<VISIT> visits,int qabrestoon_flag)
{
  if (qabrestoon_flag == 0)
  {
    print_output(visits);
  }
}

vector<int> calculate_transportation_time(vector<VISIT> &visits)
{
  vector<int> time_after_transportation;
  int finishing_hour, finishing_minute;
  finishing_hour = visits[visits.size()-1].visit_finishing_time_hour ;
  finishing_minute = visits[visits.size()-1].visit_finishing_time_minute;
  finishing_minute += TRANSPORT_TIME;
  if(finishing_minute < HOUR_DURATION)
    {
      time_after_transportation.push_back(finishing_hour);
      time_after_transportation.push_back(finishing_minute);
    }
  else
  {
    finishing_hour ++ ;
    finishing_minute = finishing_minute -HOUR_DURATION;
    time_after_transportation.push_back(finishing_hour);
    time_after_transportation.push_back(finishing_minute);
  }
  return time_after_transportation;
}

bool place_is_open_now(vector<int> arriving_time, vector<DATA> inputs, vector <int> &indexes , int i )
{
  if ((arriving_time[0]> inputs[indexes[i]].opening_time_hour) && (arriving_time[0] < inputs[indexes[i]].closing_time_hour))
    return true;
  else if ((arriving_time[0]> inputs[indexes[i]].opening_time_hour)
       && ((arriving_time[0] == inputs[indexes[i]].closing_time_hour) && (arriving_time[1] <=  inputs[indexes[i]].closing_time_minute)))
    return true;
  else if (((arriving_time[0] == inputs[indexes[i]].opening_time_hour) &&(arriving_time[1]>= inputs[indexes[i]].opening_time_minute))
          &&(arriving_time[0] < inputs[indexes[i]].closing_time_hour))
    return true;
  else if (((arriving_time[0] == inputs[indexes[i]].opening_time_hour) &&(arriving_time[1]>= inputs[indexes[i]].opening_time_minute))
         &&((arriving_time[0] == inputs[indexes[i]].closing_time_hour) && (arriving_time[1] <=  inputs[indexes[i]].closing_time_minute)))
    return true;
  else
  return false;
}

bool place_will_be_open(vector<int> arriving_time, vector<DATA> inputs, vector <int> &indexes , int i)
{
  if ((arriving_time[0]< inputs[indexes[i]].opening_time_hour)||
  ((arriving_time[0] == inputs[indexes[i]].opening_time_hour) &&(inputs[indexes[i]].opening_time_minute - arriving_time[1]) > 0))
    return true;
}

bool check_closing_time_is_more_than_1h_1(vector<int> arriving_time,vector<DATA> inputs, vector <int> &indexes , int i)
{
  if (inputs[indexes[i]].closing_time_hour - arriving_time[0] >1)
    return true;
  else if ((inputs[indexes[i]].closing_time_hour - arriving_time[0] == 1 ) &&(inputs[indexes[i]].closing_time_minute > arriving_time[1]))
    return true;
  else
    return false;
}
bool check_closing_time_is_more_than_1h_2(vector<int> arriving_time,vector<DATA> inputs, vector <int> &indexes , int i)
{
  if (inputs[indexes[i]].closing_time_hour - inputs[indexes[i]].opening_time_hour >1)
    return true;
  else if ((inputs[indexes[i]].closing_time_hour - inputs[indexes[i]].opening_time_hour == 1 ) &&(inputs[indexes[i]].closing_time_minute > inputs[indexes[i]].opening_time_minute))
    return true;
  else
    return false;
}
void find_next_visit(vector<VISIT> &visits, vector<DATA> inputs, vector <int> &indexes,int &visits_are_over)
{
  VISIT current_visit;
  vector<int> arriving_time = calculate_transportation_time(visits);
  for (int i =0; i<indexes.size(); i++)
  {
    if (place_is_open_now(arriving_time,inputs,indexes,i) && enough_time_left_to_close(inputs,indexes,i))
    {
      current_visit.name_of_place = inputs[indexes[i]].name;
      current_visit.visit_starting_time_hour = arriving_time[0];
      current_visit.visit_starting_time_minute = arriving_time[1];
      if (check_closing_time_is_more_than_1h_1(arriving_time,inputs,indexes,i))
        {
          current_visit.visit_finishing_time_hour = arriving_time[0] +1;
          current_visit.visit_finishing_time_minute = arriving_time[1];
        }
      else
        {
          current_visit.visit_finishing_time_hour = inputs[indexes[i]].closing_time_hour;
          current_visit.visit_finishing_time_minute =inputs[indexes[i]].closing_time_minute;
        }

      visits.push_back(current_visit);
      indexes.erase(indexes.begin()+i);
      visits_are_over = 0;
      break;
    }
    else if (place_will_be_open(arriving_time,inputs,indexes,i) && enough_time_left_to_close(inputs,indexes,i))
    {
      current_visit.name_of_place = inputs[indexes[i]].name;
      current_visit.visit_starting_time_hour = inputs[indexes[i]].opening_time_hour;
      current_visit.visit_starting_time_minute = inputs[indexes[i]].opening_time_minute;
      if (check_closing_time_is_more_than_1h_2(arriving_time,inputs,indexes,i))
        {
           current_visit.visit_finishing_time_hour = inputs[indexes[i]].opening_time_hour +1;
           current_visit.visit_finishing_time_minute = inputs[indexes[i]].opening_time_minute;
        }
        else
        {
          current_visit.visit_finishing_time_hour = inputs[indexes[i]].closing_time_hour;
          current_visit.visit_finishing_time_minute =inputs[indexes[i]].closing_time_minute;
        }
      visits.push_back(current_visit);
      indexes.erase(indexes.begin()+i);
      visits_are_over = 0;
      break;
    }
  }
}

bool enough_time_left_to_close(vector<DATA> inputs, vector <int> &indexes, int i)
{
  if (((inputs[indexes[i]].closing_time_hour - inputs[indexes[i]].opening_time_hour) > 0)
    ||(((inputs[indexes[i]].closing_time_hour - inputs[indexes[i]].opening_time_hour) == 0)
      &&(inputs[indexes[i]].closing_time_minute - inputs[indexes[i]].opening_time_minute) > 15))
    {
      return true;
    }
  else
    {
      return false;
    }
}

void first_visit(vector<VISIT> &visits, vector<DATA> inputs, vector <int> &indexes, int &flag)
{
  VISIT first;
  for (int i = 0; i< indexes.size(); i++)
  {
    if(enough_time_left_to_close(inputs, indexes, i))
    {
      first.name_of_place = inputs[indexes[i]].name;
      first.visit_starting_time_hour = inputs[indexes[i]].opening_time_hour;
      first.visit_starting_time_minute = inputs[indexes[i]].opening_time_minute;
      if (( inputs[indexes[i]].closing_time_hour -inputs[indexes[i]].opening_time_hour > 1)
        ||(( inputs[indexes[i]].closing_time_hour -inputs[indexes[i]].opening_time_hour == 1) && inputs[indexes[i]].closing_time_minute > inputs[indexes[i]].opening_time_minute))
        {
          first.visit_finishing_time_hour = inputs[indexes[i]].opening_time_hour +1;
          first.visit_finishing_time_minute = inputs[indexes[i]].opening_time_minute;
        }
      else
      {
        first.visit_finishing_time_hour = inputs[indexes[i]].closing_time_hour;
        first.visit_finishing_time_minute =inputs[indexes[i]].closing_time_minute;
      }
      visits.push_back(first);
      indexes.erase(indexes.begin());
      break;
    }
    else
    {
      flag = 1;
      //cout << "to miri qabrestoon" << endl;
      break;
    }
  }
}



 void what_time_is_it_now(vector<DATA> inputs,vector<int> indexes)
{
  vector<int> opening_hours;
  vector<int>opening_minuts;
  for ( int i =0; i< inputs.size();i++)
  {
    opening_hours.push_back(inputs[indexes[i]].opening_time_hour);
    opening_minuts.push_back(inputs[indexes[i]].opening_time_minute);
  }

  int minElementIndex = min_element(opening_hours.begin(),opening_hours.end()) - opening_hours.begin();
  int minElement = *min_element(opening_hours.begin(), opening_hours.end());
}

int time_difference(int hour1, int min1, int hour2, int min2)
{
  if((hour1 == hour2)&&(min1 == min2))
    return 0;
  else if ((hour1 == hour2)&&(min1 > min2))
    return 1;
  else if ((hour1 == hour2)&&(min1 < min2))
    return -1;
  else if (hour1> hour2)
    return 1;
  else if (hour1< hour2)
    return -1;
}

void merge_sort(vector<int>& indexes,vector<DATA> inputs, int low, int mid, int high)
 {	vector<int> temp;
	  int i, j;
	  i = low;
	  j = mid + 1;
	while (i <= mid && j <= high)
  {
		if (time_difference(inputs[indexes[i]].opening_time_hour,inputs[indexes[i]].opening_time_minute,inputs[indexes[j]].opening_time_hour,inputs[indexes[j]].opening_time_minute) <= 0)
    {
			temp.push_back(indexes[i]);
			++i;
		}
		else if(time_difference(inputs[indexes[i]].opening_time_hour,inputs[indexes[i]].opening_time_minute,inputs[indexes[j]].opening_time_hour,inputs[indexes[j]].opening_time_minute) == 1)
    {
			temp.push_back(indexes[j]);
			++j;
		}
	}
	while (i <= mid) {
		temp.push_back(indexes[i]);
		++i;
	}
	while (j <= high) {
		temp.push_back(indexes[j]);
		++j;
	}
	for (int i = low; i <= high; ++i)
		indexes[i] = temp[i - low];
}

void merge_sort_times(vector<int>& v,vector<DATA> inputs, int low, int high)
{
	if (low < high) {
		int mid = (low + high) / 2;
		merge_sort_times(v, inputs,low, mid);
		merge_sort_times(v, inputs,mid + 1, high);
		merge_sort(v,inputs ,low, mid, high);
	}
}

void sort_ranks(vector<DATA> inputs, vector <int> &indexes)
{
  for(int i = 1 ; i<indexes.size(); i++)
  {
    if ((time_difference(inputs[indexes[i]].opening_time_hour,inputs[indexes[i]].opening_time_minute,inputs[indexes[i-1]].opening_time_hour,inputs[indexes[i-1]].opening_time_minute) == 0)
      &&(inputs[indexes[i]].rank < inputs[indexes[i-1]].rank))
    {
      swap(indexes[i],indexes[i-1]);
    }
  }

}

void save_organized_inputs(vector<DATA> &inputs,vector <string> words,vector<string> splited_columns, int num_of_lines)
{
  for (int k = 0 ; k< num_of_lines; k++)
  {
    organize_input(inputs,words,splited_columns, num_of_lines,k+1);
  }
}
vector<string> split (string str, char seperator)
{
    int current_index =0;
    int i =0;
    int starting_index =0;
    int ending_index =0;
    vector <string> strings_in_line;
    while (i <= str.length())
    {
      if (str[i] == seperator || i == str.length())
      {
        ending_index = i;
        string sub_str = "";
        sub_str.append(str, starting_index, ending_index - starting_index);
        strings_in_line.push_back(sub_str);
        current_index +=1;
        starting_index = ending_index +1;
      }
      i++ ;
    }
    return strings_in_line;
 }
 int convert_char_to_int(string a)
 {
   stringstream str;
   str << a;
   int converted_to_int;
   str >> converted_to_int;
   return converted_to_int;
 }
void get_first_input_line(vector<string> &splited_columns, ifstream &input_file)
{
  string first_line;
  getline(input_file,first_line);
  splited_columns = split(first_line,CAMMA_SEPERATOR);
}
void get_other_input_lines(vector <string> &words,ifstream &input_file)
{
  while (input_file)
  {
    vector<string> splited;
    string line;
    getline(input_file,line);
    splited = split(line,CAMMA_SEPERATOR);
    for (int i = 0; i<splited.size(); i++)
    {
      words.push_back(splited[i]);
    }
  }
  words.pop_back();
}

void read_from_file(vector <string> &words, vector<string> &splited_columns, char* file_name)
{
  ifstream input_file;
  input_file.open(file_name);
  get_first_input_line(splited_columns,input_file);
  get_other_input_lines(words,input_file);
}

vector<int> read_time(string time)
{
  vector<int> result;
  vector<string> splited_time = split(time, COLON_SEPERATOR);
  int hour = convert_char_to_int(splited_time[0]);
  result.push_back(hour);
  int minute = convert_char_to_int(splited_time[1]);
  result.push_back(minute);
  return result;
}

void organize_input(vector<DATA> &input,vector <string> words,vector<string> splited_columns, int num_of_lines, int i)
{
  DATA temp;
    for (int j = 0;j < NUM_OF_COLUMNS; j++)
      {
        if(splited_columns[j] == PLACE_NAME)
          temp.name = words[4*(i-1)+j];
        if (splited_columns[j] == PLACE_RANK)
          temp.rank = convert_char_to_int(words[4*(i-1)+j]);
        if (splited_columns[j] == openingTime)
        {
          temp.opening_time_hour = read_time(words[4*(i-1)+j])[0];
          temp.opening_time_minute = read_time(words[4*(i-1)+j])[1];
        }
        if (splited_columns[j] == closingTime)
        {
          temp.closing_time_hour = read_time(words[4*(i -1)+j])[0];
          temp.closing_time_minute = read_time(words[4*(i -1)+j])[1];
        }
      }
    input.push_back(temp);
}
